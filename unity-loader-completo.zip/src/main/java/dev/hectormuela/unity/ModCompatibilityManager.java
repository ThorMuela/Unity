package dev.hectormuela.unity;

public class ModCompatibilityManager {
    public static void loadCompatibleMods() {
        System.out.println("Cargando mods de Fabric y NeoForge...");
    }
}
